# -*- coding: utf-8 -*-

import os, sys
import pandas as pd
import matplotlib.pyplot as plt
import xml.etree.ElementTree as ET
import numpy as np
from BayesianOptimizaiton import BO

if 'SUMO_HOME' in os.environ:
    tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
    sys.path.append(tools)
else:
    sys.exit("Please declare the environment variable 'SUMO_HOME'")

import traci
from sumolib import checkBinary

# run simulation and retrieve data
def writing_vType_xml(path,parameter):
    '''
    修改vType文件的速度分布值和车辆比例
    '''
    tree = ET.parse(path)
    root = tree.getroot()
    for vType in root.findall("vType"):
        vType.set("speedFactor",'normc(' + str(min(max(parameter,0.2),2)) + ',0.1,0.2,2)')
    tree.write(path, encoding="UTF-8",xml_declaration=True)

def run(duration):
    """
    run simulation
    """
    step = 0
    n = 0
    for step in range(int(duration)):
        traci.simulationStep()
    traci.close()

def simulation_automatically(simulation_path,duration,seed=42,gui=False):
    """
    traci simulation
    """
    path = simulation_path + "\\Start_Simulation.sumocfg"
    if 'SUMO_HOME' in os.environ:
        tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
        sys.path.append(tools)
    else:
        sys.exit("please declare environment variable 'SUMO_HOME'")
    if gui:
        sumoBinary=checkBinary("sumo-gui")
    else:
        sumoBinary=checkBinary("sumo")
   
    
    traci.start([sumoBinary, "-c", path, "--seed", str(seed), "-W", "true"])
    run(duration)
    
#simualtion setup
def run_simulation(x, simulation_path,seed=42,gui=False):

    vType_path=simulation_path+"\\1_fast.rou.xml"
    parameter=x[0]
    writing_vType_xml(vType_path,parameter)

    vType_path=simulation_path+"\\1_mid.rou.xml"
    parameter=(0.7583/0.8293)*x[0]
    writing_vType_xml(vType_path,parameter)

    vType_path=simulation_path+"\\1_slow.rou.xml"
    parameter=(0.6248/0.8293)*x[0]
    writing_vType_xml(vType_path,parameter)

    vType_path=simulation_path+"\\2_fast.rou.xml"
    parameter=x[1]
    writing_vType_xml(vType_path,parameter)

    vType_path=simulation_path+"\\2_mid.rou.xml"
    parameter=(0.7714/0.8903)*x[1]
    writing_vType_xml(vType_path,parameter)

    vType_path=simulation_path+"\\2_slow.rou.xml"
    parameter=(0.7132/0.8903)*x[1]
    writing_vType_xml(vType_path,parameter)

    duration=4800
    simulation_automatically(simulation_path,duration,seed,gui)

def get_observation_flow(obs_path,start_time,end_time,obs_deta_time):

    path = obs_path+"\\e1_detector.xml"
    tree = ET.parse(path)
    root = tree.getroot()
    Info = []
    duration=end_time-start_time
    for interval in root.findall("interval"):
        t = float(interval.get("begin"))
        dec_id1 = interval.get("id")
        dec_id=dec_id1[:-2]
        veh=float(interval.get("flow"))*4
        Info.append([(t-start_time)//obs_deta_time,dec_id,veh])
    df_simulation = pd.DataFrame(Info)
    df_simulation.columns = ["interval","id","flow"]
    df_simulation=df_simulation.loc[df_simulation['interval']<(duration//obs_deta_time)]
    return df_simulation

def get_observation_speed(obs_path,start_time,end_time,obs_deta_time):

    path = obs_path+"\\e1_detector.xml"
    tree = ET.parse(path)
    root = tree.getroot()
    Info = []
    duration=end_time-start_time
    for interval in root.findall("interval"):
        t = float(interval.get("begin"))
        dec_id1 = interval.get("id")
        dec_id=dec_id1[:-2]
        speed=float(interval.get("speed"))
        Info.append([(t-start_time)//obs_deta_time,dec_id,speed])
    df_simulation = pd.DataFrame(Info)
    df_simulation.columns = ["interval","id","speed"]
    df_simulation=df_simulation.loc[df_simulation['interval']<(duration//obs_deta_time)]
    return df_simulation


def get_True_data(path):

    path_flow=path+"\\true_flow.csv"
    path_speed=path+"\\true_speed.csv"
    True_data_flow=pd.read_csv(path_flow)  
    True_data_speed=pd.read_csv(path_speed)  
    return True_data_flow,True_data_speed

def mape(df,key_parameter):
    if df[key_parameter+'_y']==0:
        return np.nan
    else:
        return abs(df[key_parameter+'_x']-df[key_parameter+'_y'])/df[key_parameter+'_y']

def ae(df,key_parameter):
    return abs(df[key_parameter+'_x']-df[key_parameter+'_y'])

def cal_sim_mape(obs_df,true_df,key_id,key_interval,key_parameter):
    obs_data_group=obs_df.groupby([key_id,key_interval]).mean()[key_parameter]
    true_data_group=true_df.groupby([key_id,key_interval]).mean()[key_parameter]
    obs_true_df=pd.merge(obs_data_group,true_data_group,left_index=True,right_index=True)
    
    obs_true_df['MAPE']=obs_true_df.apply(mape,axis=1,args=(key_parameter,))
    MAPE=obs_true_df['MAPE'].mean()
    
    # obs_true_df['AE']=obs_true_df.apply(ae,axis=1,args=(key_parameter,))
    # WMAPE=obs_true_df['AE'].sum()/obs_true_df[key_parameter+'_y'].sum()
    
    return MAPE
    # return WMAPE

def objective_function_sim(x,seed=42,gui=False):
    simulation_path = os.getcwd()
    obs_path = os.getcwd()
    start_time=0
    end_time=4800
    obs_deta_time=600
    tru_flow_df,tru_speed_df=get_True_data(obs_path)
    run_simulation(x, simulation_path,seed,gui)
    obs_flow_df=get_observation_flow(obs_path,start_time,end_time,obs_deta_time)
    obs_speed_df=get_observation_speed(obs_path,start_time,end_time,obs_deta_time)
    MAPE_flow=cal_sim_mape(obs_flow_df,tru_flow_df,"id","interval","flow")
    MAPE_speed=cal_sim_mape(obs_speed_df,tru_speed_df,"id","interval","speed")
    print('x:', x, 'MAPE_flow:', str(100*MAPE_flow)+'%', 'MAPE_speed:', str(100*MAPE_speed)+'%')
    y=[10*MAPE_flow, 10*MAPE_speed]
    return 0.2*y[0] + 0.8*y[1]

def plot_tru_obs(obs_df,true_df,key_id,key_interval,key_parameter):
    obs_data_group=obs_df.groupby([key_id,key_interval]).mean()[key_parameter]
    true_data_group=true_df.groupby([key_id,key_interval]).mean()[key_parameter]
    obs_true_df=pd.merge(obs_data_group,true_data_group,left_index=True,right_index=True)
    plt.figure()
    plt.plot(list(obs_true_df[key_parameter+'_x']),label='Sim',marker='o',markersize=8,linewidth=2,linestyle='--')
    plt.plot(list(obs_true_df[key_parameter+'_y']),label='True',marker='^',markersize=8,linewidth=2)
    plt.xticks(fontsize=13)
    plt.yticks(fontsize=13)
    plt.xlabel('interval(185s)',fontsize=13)
    plt.ylabel(key_parameter,fontsize=13)
    plt.legend(fontsize=13)
    return obs_true_df

def show_performance(obs_path,start_time,end_time,obs_deta_time):
    tru_flow_df,tru_speed_df=get_True_data(obs_path)
    obs_flow_df=get_observation_flow(obs_path,start_time,end_time,obs_deta_time)
    obs_speed_df=get_observation_speed(obs_path,start_time,end_time,obs_deta_time)
    obs_true_flow_df=plot_tru_obs(obs_flow_df,tru_flow_df,"id","interval","flow")
    obs_true_speed_df=plot_tru_obs(obs_speed_df,tru_speed_df,"id","interval","speed")
    return obs_true_flow_df, obs_true_speed_df
    

if __name__ == '__main__':
    
    problem_dimension = 2
    upper_bound = [2.0, 2.0]
    lower_bound = [0.5, 0.5]
    init_sample_num = 5
    BO_solver = BO(problem_dimension, upper_bound, lower_bound, init_sample_num)
    opt_parameter = BO_solver.minimization(objective_function_sim)
    
    